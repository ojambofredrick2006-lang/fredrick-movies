# FREDRICK MOVIES

A Node.js + Express starter for a subscription-based movie catalogue. Includes registration/login, admin movie management, video link embedding, local video upload, subscription expiry logic, and a Flutterwave checkout/verification flow.

## Important before publishing

- Only publish movies you own or have permission to stream. A video URL may not be legally distributable or embeddable.
- Payment integration requires an approved Flutterwave account and valid secret credentials. Do not put secret keys in browser code or share them publicly.
- The default price is **UGX 500 for 30 days**, not exactly USD $0.10. This is configurable using `SUBSCRIPTION_PRICE_UGX`. Check current exchange rates, payment-provider fees, minimum charges, and account eligibility before selecting your final price.
- This is a starter project, not a fully audited production streaming service. Before accepting real money, test the entire payment flow with provider test credentials and ask a developer to review security, deployment persistence, backups, and payment webhook handling.
- Uploaded files and SQLite data are stored on the server filesystem. Some free hosting providers delete local files or use ephemeral storage. For reliable production use, move videos to durable object storage and the database to a managed database.
- Third-party video hosts may block embedding. The website cannot bypass those restrictions.
- Automatic payments are disabled until credentials are configured.

## Run locally

Requirements: Node.js 20 or newer.

1. Extract the ZIP.
2. Open a terminal in the `fredrick-movies` folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Copy `.env.example` to `.env`.
5. Change `SESSION_SECRET`, `ADMIN_EMAIL`, and `ADMIN_PASSWORD` in `.env`.
6. For local preview, leave Flutterwave keys blank; browsing, account registration, and admin catalogue management will still work.
7. Start:

   ```bash
   npm start
   ```

8. Open `http://localhost:3000`.

## Configure Flutterwave

1. Create/verify your merchant account directly with Flutterwave and check which Ugandan payment methods your account supports.
2. Set `FLW_SECRET_KEY` in the server environment. `FLW_PUBLIC_KEY` is not used by this server-side hosted checkout flow, but you may keep it for later.
3. Set `BASE_URL` to your actual HTTPS website origin, for example `https://your-domain.example`.
4. Set `SUBSCRIPTION_PRICE_UGX` to the amount you intend to charge in UGX.
5. Configure the payment provider for UGX/mobile money as supported by your account.
6. Test with provider test credentials before going live.

The server creates a checkout and verifies the returned transaction with Flutterwave's transaction verification endpoint. It checks transaction status, reference, currency, amount, and the logged-in user's pending payment. Do not treat a browser redirect alone as proof of payment.

**Production hardening still required:** Add a signed webhook handler with replay/idempotency controls, rate limiting, CSRF protection, email verification/password reset, stronger audit logging, durable storage, monitoring, and a security review. Do not accept real payments until these are implemented and tested for your provider/account.

## Admin access

The first administrator is created on startup from `ADMIN_EMAIL` and `ADMIN_PASSWORD` if that email does not already exist. Change these values before publishing. Sign in and open `/admin`.

## Adding movies

In the admin dashboard, provide:
- Title, category, description
- Optional poster image URL
- Either a permitted video URL or a video file (up to 500 MB)

YouTube and Vimeo links are converted to embed URLs when recognized. Some external hosts do not allow embedding. Direct video URLs need to point to a playable file and must be hosted with permission.

## Deployment notes

A typical Node-compatible host can run this project with `npm install` and `npm start`. Configure all `.env` values in the host's environment-variable settings; do not upload your `.env` file. Confirm whether the host supports persistent disks before using local SQLite or video uploads. If it does not, switch to a managed database and durable object storage first.

## Contact

The site currently displays: `0700975576`. Update `CONTACT_PHONE` in `.env` if needed.
